﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace final3332.Services
{
    public class CheckResult
    {
      
        public bool verify(int number1, int number2)
        {
            if (number1 + number2 == 30)
                return true;
            return false;
        }
        
    }
}
