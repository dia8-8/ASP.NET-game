﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using final3332.Data;
using final3332.Models;
using System.ComponentModel.DataAnnotations;

namespace final3332.Pages
{
    public class IndexModel : PageModel
    {
      

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public InputModel  Game { get; set; }

       
        
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid )
            {
                return Page();
            }
            if (Game.number1<=10 || Game.number1>=20 || Game.number2<=10 || Game.number2>=20)
            {
                ModelState.AddModelError("InputError", "number1 and number2  should be between 10 and 20");
                return Page();

            }
               
            return RedirectToPage("./Result",Game);
        }

        public class InputModel
        {
            [Required]
            [Display(Name ="your full name")]
            public string fullname { get; set; }

            [Required]
            [Display(Name = "your first number")]
            public int number1 { get; set; }
            [Required]
            [Display(Name = "your second number")]
            public int number2 { get; set; }
        }
    }
}
