using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using final3332.Data;
using final3332.Models;
using final3332.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace final3332.Pages
{
    public class ResultModel : PageModel
    {
        private readonly CheckResult _checkResult;
        private readonly ApplicationDbContext _context;

        public ResultModel(CheckResult checkResult,ApplicationDbContext applicationDbContext)
        {
            _checkResult = checkResult;
            _context = applicationDbContext;
        }
        
        public class InputModel
        {
        
            public string fullname { get; set; }

           
            public int number1 { get; set; }
          
            public int number2 { get; set; }
        }
        [BindProperty(SupportsGet = true)]
        public InputModel Game { get; set; }

        public  string result { get; set; }

        public int  wonamount { get; set; }

        public async Task OnGet()
        {
            if (_checkResult.verify(Game.number1, Game.number2))
            {
                wonamount = 2 * Game.number1 * Game.number2;
                result = "Congratulation You won";
                Game game = new() { fullname = Game.fullname, number1 = Game.number1, number2 = Game.number2, WonAmount = 2 * Game.number1 * Game.number2 };
                _context.Game.Add(game);
                await _context.SaveChangesAsync();

            }
            else
            {
                result = "You lost try again baby";
            }

        }
    }
}
