﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace final3332.Models
{
    public class Game
    {
        public int GameId { get; set; }
        [Required]
        public string fullname { get; set; }
        [Required]
        public int number1 { get; set; }
        [Required]
        public int number2 { get; set; }
        [Required]
        public int WonAmount { get; set; }


    }
}
